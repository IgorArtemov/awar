from config import *
#EXCHANGES = ['COINEX']
EXCHANGES = ['CRYPTSY']
PAIRS = [("LTC","BTC")]