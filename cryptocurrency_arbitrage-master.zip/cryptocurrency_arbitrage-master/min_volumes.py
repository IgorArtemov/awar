# stores minimum volume orders for each market.
# these

