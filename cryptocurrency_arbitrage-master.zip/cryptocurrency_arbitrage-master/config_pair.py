from config import *

USE_MULTITHREADED = False
EXCHANGES = ['CRYPTO-TRADE', 'BTCE', 'COINS-E', 'CRYPTSY']
# 'COINEX' is down, will be back up soon
# 'BTER' also doing weird shit...
# 'VIRCUREX' is insolvent...
#PAIRS = [("LTC","BTC"), ("DOGE", "BTC"), ("PPC","BTC"), ("NXT","BTC"), ("WDC","BTC"),
#       ("DOGE","LTC"), ("PPC","LTC")]

#EXCHANGES = ['BTER']
PAIRS = [("LTC","BTC"), ("DOGE","BTC")]
MODE = 'BACKTEST'
